package br.com.fiap.cookcraft.service

import br.com.fiap.cookcraft.model.Receita
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.Path

interface ReceitaService {
    //BASE_URL - http://localhost:8080/api/v1/

    @Headers("Content-Type: application/json")
    @GET("receitas")
    fun getAllReceita(
    ): Call<List<Receita>>

    @GET("receitas/{nomeReceita}")
    fun getReceitaByName(@Path("nomeReceita") nomeReceita: String): Call<Receita>

}