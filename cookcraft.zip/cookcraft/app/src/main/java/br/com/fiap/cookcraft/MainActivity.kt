package br.com.fiap.cookcraft

import android.os.Bundle
import android.telecom.Call.Details
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

import br.com.fiap.cookcraft.screens.CadastroScreen
import br.com.fiap.cookcraft.screens.HomeScreen
import br.com.fiap.cookcraft.screens.IngredienteScreen
import br.com.fiap.cookcraft.screens.LoginScreen
import br.com.fiap.cookcraft.screens.ReceitaScreen
import br.com.fiap.cookcraft.ui.theme.CookcraftTheme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CookcraftTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    NavHost(
                        navController = navController,
                        startDestination = "login"
                    ) {
                        composable(route = "login") {
                            LoginScreen(navController)
                        }
                        composable(route = "home/{token}") {
                            val token = it.arguments?.getString("token")
                            HomeScreen(
                                navController,
                                token!!
                            )//double bang - trata um null ou undefined de um argument "?"
                        }
                        composable(route = "cadastro") {
                            CadastroScreen(navController)
                        }
                        composable(route = "ingrediente") {
                            IngredienteScreen(navController)
                        }
                        composable(route = "receita/{token}") {
                            val token = it.arguments?.getString("token")
                            ReceitaScreen(navController, token!!)
                        }

                    }
                }
            }
        }
    }
}

