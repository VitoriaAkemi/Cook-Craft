package br.com.fiap.cookcraft.model

data class Auth(
    val user: String = "",
    val password: String = ""
)
