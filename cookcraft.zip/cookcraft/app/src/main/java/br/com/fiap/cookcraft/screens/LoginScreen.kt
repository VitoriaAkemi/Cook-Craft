package br.com.fiap.cookcraft.screens


import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import br.com.fiap.cookcraft.R
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import br.com.fiap.cookcraft.components.CaixaDeDialogo
import br.com.fiap.cookcraft.model.Auth
import br.com.fiap.cookcraft.model.LoginResponse
import br.com.fiap.cookcraft.service.RetrofitFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response



@Composable
fun LoginScreen(
    navController: NavController

) {
    var password by remember {
        mutableStateOf("")
    }

    var user by remember {
        mutableStateOf( "")
    }

    var tamanhoMaximo = 12

    var errorUser by remember{
        mutableStateOf(false)
    }

    var errorPassword by remember {
        mutableStateOf( false)
    }

    var loginState by remember {
        mutableStateOf(LoginResponse())
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                color = Color(253, 160, 106, 255)
            )
            .padding(32.dp),
    ){
        Column(
            modifier = Modifier
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(
                painter = painterResource(id = R.drawable.cookcraft),
                contentDescription = "Logo Cookcraft",
                modifier = Modifier
                    .size(200.dp)
            )
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Login",
                fontSize = 28.sp,
                color = Color(89,74,71,255),
                //fontFamily = R.font.architectsdaughter,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(30.dp))
        Column (
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = Color(238, 192, 158, 255),
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = user,
                    onValueChange = {user = it},
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            color = Color(255, 250, 247, 255),
                            shape = RoundedCornerShape(10.dp)
                        )
                        .border(
                            BorderStroke(
                                width = 0.5.dp,
                                color = Color(7, 72, 78, 255),
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ),

                    placeholder = {
                        Text(text = "Usuário")
                    },
                    shape = RoundedCornerShape(10.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    maxLines = 1,
                    isError = errorUser
                )

            }
            if(errorUser){
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                ){
                    Text(
                        text = "Usuário incorreto",
                        fontSize = 14.sp,
                        color = Color.Red,
                        textAlign = TextAlign.End,
                        modifier = Modifier
                            .fillMaxWidth()
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = password,
                    onValueChange = {
                        if(it.length <= tamanhoMaximo){
                            password = it
                        }
                                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            color = Color(255, 250, 247, 255),
                            shape = RoundedCornerShape(10.dp)
                        )
                        .border(
                            BorderStroke(
                                width = 0.5.dp,
                                color = Color(7, 72, 78, 255),
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ),
                    placeholder = {
                        Text(text = "Senha")
                    },
                    shape = RoundedCornerShape(10.dp),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    maxLines = 1,
                    isError = errorPassword
                )
            }
            if(errorPassword){
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                ){
                    Text(
                        text = "Senha incorreta",
                        fontSize = 14.sp,
                        color = Color.Red,
                        textAlign = TextAlign.End,
                        modifier = Modifier
                            .fillMaxWidth()
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(32.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth(),
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(
                    onClick = {
                        errorUser = user.isEmpty()

                        errorPassword = password.isEmpty()

                        var call = RetrofitFactory().postAuthByUser().authByUser(
                            Auth(user = user, password = password)
                        )
                        call.enqueue(object : Callback<LoginResponse>{
                            override fun onResponse(
                                call: Call<LoginResponse>,
                                response: Response<LoginResponse>
                            ) {
                                if(response.body() != null){
                                    loginState = response.body()!!
                                }else{
                                    loginState = LoginResponse()
                                }

                                //Log.i("Cookcraft", "onResponse: ${response.code()}")


                                if(!errorUser && !errorPassword && response.code() != 400){
                                    navController.navigate("home/${loginState.token}}")
                                }else{
                                    errorUser = true
                                    errorPassword = true
                                }
                            }

                            override fun onFailure(
                                call: Call<LoginResponse>,
                                t: Throwable
                            ) {
                                //Log.i("Cookcraft", "onResponse: ${t.message}")
                            }
                        })
//
                    },
                    colors = ButtonDefaults.buttonColors(Color(255, 250, 247, 255)),
                    modifier = Modifier
                        .width(180.dp)
                        .height(40.dp)
                        .background(
                            color = Color(255, 250, 247, 255),
                            shape = RoundedCornerShape(10.dp)
                        ),
                ) {
                    Text(
                        text = "Entrar",
                        fontSize = 20.sp,
                        color = Color(7, 72, 78, 255)
                    )
                }
            }
            Spacer(modifier = Modifier.height(22.dp))
                Row (
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ){
                    Button(
                        onClick = {navController.navigate("cadastro")},
                        colors = ButtonDefaults.buttonColors(Color(255, 250, 247, 255)),
                        modifier = Modifier
                            .width(180.dp)
                            .height(40.dp)
                            .background(
                                color = Color(255, 250, 247, 255),
                                shape = RoundedCornerShape(10.dp),
                            )
                    ) {
                        Text(
                            text = "Cadastrar",
                            fontSize = 20.sp,
                            color = Color(7, 72, 78, 255)
                        )
                    }
                }
        }
    }
}


