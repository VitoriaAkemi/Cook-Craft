package br.com.fiap.cookcraft.service

import br.com.fiap.cookcraft.model.MyInterceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetrofitFactory(){
    private val BASE_URL = "http://10.0.2.2:8080/api/v1/"

    private val retrofitFactory = Retrofit
        .Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    fun postAuthByUser(): AuthService{
        return retrofitFactory.create(AuthService::class.java)
    }

    fun getAllProfiles(): PerfisService{
        return retrofitFactory.create(PerfisService::class.java)
    }

    fun setUser(): CadastroService{
        return retrofitFactory.create(CadastroService::class.java)
    }

}