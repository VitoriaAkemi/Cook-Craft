package br.com.fiap.cookcraft.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import br.com.fiap.cookcraft.model.Receita

@Composable
fun ReceitaCard(receita: Receita){
    Column(
        modifier = Modifier
            .fillMaxSize()

    ) {
        Row (
            modifier = Modifier
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ){
            Text(
                text = "${receita.nomeReceita}",
                fontSize = 28.sp,
                color = Color(89, 74, 71, 255)
            )
        }
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Text(
                    text = "Tempo de Preparo: ${receita.tempoPreparo}",
                    fontSize = 22.sp,
                    color = Color(89, 74, 71, 255)
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Text(
                    text = "Nome do Ingrediente: ${receita.ingredientes[receita.id].nomeIngrediente}",
                    fontSize = 20.sp,
                    color = Color(89, 74, 71, 255)
                )
                Text(
                    text = "Quantidade : ${receita.ingredientes[receita.id].quantidade}",
                    fontSize = 20.sp,
                    color = Color(89, 74, 71, 255)
                )
            }
        }
    }
}