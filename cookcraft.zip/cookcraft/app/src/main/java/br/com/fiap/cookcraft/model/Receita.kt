package br.com.fiap.cookcraft.model

data class Receita(
    val id: Int = 0,
    val tempoPreparo: String = "",
    val nomeReceita: String = "",
    val ingredientes: Array<Ingrediente>
)