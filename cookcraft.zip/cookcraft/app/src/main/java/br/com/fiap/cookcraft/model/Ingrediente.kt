package br.com.fiap.cookcraft.model

data class Ingrediente(
    val id: Int = 0,
    val nomeIngrediente: String = "",
    val quantidade: String = ""
)