package br.com.fiap.cookcraft.screens

import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import br.com.fiap.cookcraft.R
import br.com.fiap.cookcraft.components.CaixaDeDialogo
import br.com.fiap.cookcraft.model.Perfil
import br.com.fiap.cookcraft.model.Usuario
import br.com.fiap.cookcraft.service.RetrofitFactory
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

@Composable
fun CadastroScreen(
    navController: NavController
){

    var firstname by remember {
        mutableStateOf("")
    }
    var lastname by remember {
        mutableStateOf("")
    }
    var user by remember {
        mutableStateOf("")
    }
    var email by remember {
        mutableStateOf("")
    }
    var password by remember {
        mutableStateOf("")
    }
    var errorFirstName by remember {
        mutableStateOf(false)
    }
    var errorLastName by remember {
        mutableStateOf(false)
    }
    var errorUser by remember {
        mutableStateOf(false)
    }
    var errorEmail by remember {
        mutableStateOf(false)
    }
    var errorPassword by remember {
        mutableStateOf(false)
    }
    var profileState by remember{
        mutableStateOf(listOf<Perfil>())
    }
    val tamanhoMaximo = 12
    var expanded by remember {
        mutableStateOf(false)
    }
    var valorProfile by remember {
        mutableStateOf("")
    }
    var errorPerfil by remember {
        mutableStateOf(false)
    }
    var valorId by remember {
        mutableStateOf(0)
    }
    var userState by remember {
        mutableStateOf(Usuario(
            user = "",
            password = "",
            firstName = "",
            lastName = "",
            email = "",
            userProfile = arrayOf(
                Perfil(
                    id = 0,
                    profileName = ""
                )
            )
        ))
    }
    var exibirDialogCadastroEfetuado by remember {
        mutableStateOf(false)
    }
    var exibirDialogCadastroNaoEfetuado by remember {
        mutableStateOf(false)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                color = Color(253, 160, 106, 255)
            )
            .padding(24.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    color = Color(238, 192, 158, 255),
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(10.dp),
                verticalArrangement = Arrangement.SpaceAround
        ) {
            if(exibirDialogCadastroEfetuado){
                CaixaDeDialogo(
                    title = "Cadastro Efetuado",
                    dialogText = "Cadastro criado com sucesso",
                    primaryAction = {exibirDialogCadastroEfetuado = false},
                    corDaTela = Color(178, 209, 167, 255)
                )
            }
            if(exibirDialogCadastroNaoEfetuado){
                CaixaDeDialogo(
                    title = "Cadastro não efetuado",
                    dialogText = "Por favor, verifique os campos",
                    primaryAction = {exibirDialogCadastroNaoEfetuado = false},
                    corDaTela = Color(209, 167, 167, 255)
                )
            }
            Row (
                //Header
                modifier = Modifier
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ){
                Column() {
                    Text(
                        text = "Cadastro",
                        fontSize = 22.sp,
                        color = Color(7, 72, 78, 255)
                    )
                }
                Column() {
                    Image(
                        painter = painterResource(id = R.drawable.cookcraft_logo2),
                        contentDescription = "Logo Cookcraft",
                        modifier = Modifier
                            .size(width = 160.dp, height = 80.dp)
                            .clip(
                                shape = RoundedCornerShape(6.dp)
                            ),
                    )
                }
            }
            //Spacer(modifier = Modifier.height(10.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Row (
                    modifier = Modifier
                        .fillMaxWidth()
                ){
                    OutlinedTextField(
                        value = firstname,
                        onValueChange = {
                            firstname = it
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                        maxLines = 1,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = Color(255, 250, 247, 255),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .border(
                                BorderStroke(
                                    width = 0.5.dp,
                                    color = Color(7, 72, 78, 255),
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ),
                        placeholder = {
                            Text(text = "Nome")
                        },
                        shape = RoundedCornerShape(10.dp),
                        isError = errorFirstName
                    )
                }
                if(errorFirstName){
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                    ){
                        Text(
                            text = "Preencha o nome",
                            fontSize = 14.sp,
                            color = Color.Red,
                            textAlign = TextAlign.End,
                            modifier = Modifier
                                .fillMaxWidth()
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row (
                    modifier = Modifier
                        .fillMaxWidth()
                ){
                    OutlinedTextField(
                        value = lastname,
                        onValueChange = {
                            lastname = it
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                        maxLines = 1,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = Color(255, 250, 247, 255),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .border(
                                BorderStroke(
                                    width = 0.5.dp,
                                    color = Color(7, 72, 78, 255),
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ),
                        placeholder = {
                            Text(text = "Sobrenome", fontSize = 18.sp)
                        },
                        shape = RoundedCornerShape(10.dp),
                        isError = errorLastName
                    )
                }
                if(errorLastName){
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                    ){
                        Text(
                            text = "Preencha o sobrenome",
                            fontSize = 14.sp,
                            color = Color.Red,
                            textAlign = TextAlign.End,
                            modifier = Modifier
                                .fillMaxWidth()
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row (
                    modifier = Modifier
                        .fillMaxWidth()
                ){
                    OutlinedTextField(
                        value = user,
                        onValueChange = {
                            user = it
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                        maxLines = 1,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = Color(255, 250, 247, 255),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .border(
                                BorderStroke(
                                    width = 0.5.dp,
                                    color = Color(7, 72, 78, 255),
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ),
                        placeholder = {
                            Text(text = "Crie um usuário de acesso", fontSize = 18.sp)
                        },
                        shape = RoundedCornerShape(10.dp),
                        isError = errorUser
                    )
                }
                if(errorUser){
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                    ){
                        Text(
                            text = "Preencha um usuário",
                            fontSize = 14.sp,
                            color = Color.Red,
                            textAlign = TextAlign.End,
                            modifier = Modifier
                                .fillMaxWidth()
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row (
                    modifier = Modifier
                        .fillMaxWidth()
                ){
                    OutlinedTextField(
                        value = email,
                        onValueChange = {
                            email = it
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        maxLines = 1,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = Color(255, 250, 247, 255),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .border(
                                BorderStroke(
                                    width = 0.5.dp,
                                    color = Color(7, 72, 78, 255),
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ),
                        placeholder = {
                            Text(text = "Digite seu e-mail", fontSize = 18.sp)
                        },
                        shape = RoundedCornerShape(10.dp),
                        isError = errorEmail
                    )
                }
                if(errorEmail){
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                    ){
                        Text(
                            text = "Preencha o e-mail",
                            fontSize = 14.sp,
                            color = Color.Red,
                            textAlign = TextAlign.End,
                            modifier = Modifier
                                .fillMaxWidth()
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row (
                    modifier = Modifier
                        .fillMaxWidth()
                ){
                    OutlinedTextField(
                        value = password,
                        onValueChange = {
                            if(it.length <= tamanhoMaximo){
                                password = it
                            }
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        maxLines = 1,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = Color(255, 250, 247, 255),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .border(
                                BorderStroke(
                                    width = 0.5.dp,
                                    color = Color(7, 72, 78, 255),
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ),
                        placeholder = {
                            Text(text = "Digite uma senha", fontSize = 18.sp)
                        },
                        shape = RoundedCornerShape(10.dp),
                        isError = errorPassword
                    )
                }
                if(errorPassword){
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                    ){
                        Text(
                            text = "Preencha uma senha",
                            fontSize = 14.sp,
                            color = Color.Red,
                            textAlign = TextAlign.End,
                            modifier = Modifier
                                .fillMaxWidth()
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row (
                    modifier = Modifier
                        .fillMaxWidth()
                ){
                    Column() {
                        IconButton(
                            onClick = {
                                expanded = true

                                var call = RetrofitFactory().getAllProfiles().getAllPerfis()

                                call.enqueue(object: Callback<List<Perfil>>{
                                    override fun onResponse(
                                        call: Call<List<Perfil>>,
                                        response: Response<List<Perfil>>
                                    ) {
                                        if(response.code() != 400){
                                            profileState = response.body()!!

                                        }
                                    }

                                    override fun onFailure(
                                        call: Call<List<Perfil>>,
                                        t: Throwable
                                    ) {
                                        Log.i("Cookcraft", "onResponse: ${t.message}")
                                    }
                                } )

                                      },
                            modifier = Modifier
                                .size(56.dp)
                                .background(
                                    color = Color(255, 250, 247, 255),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .border(
                                    BorderStroke(
                                        width = 0.5.dp,
                                        color = Color(7, 72, 78, 255),
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                )
                        ) {
                            Icon(
                                Icons.Default.Person,
                                contentDescription = "Perfil",
                                tint = Color(7, 72, 78, 255)
                            )
                        }
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = {expanded = false},
                            modifier = Modifier
                                .background(
                                    color = Color(7, 72, 78, 255)
                                )
                                .padding(0.dp)
                        ) {
                            for (profile in profileState) {
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = "${profile.profileName}",
                                            fontSize = 18.sp,
                                            modifier = Modifier
                                                .fillMaxSize(),
                                            textAlign = TextAlign.Center
                                        )
                                    },
                                    onClick = {
                                        valorProfile = "${profile.profileName}"
                                        valorId = profile.id
                                    },
                                    modifier = Modifier
                                        .background(
                                            color = Color(255, 250, 247, 255),
                                        ),
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column() {
                        OutlinedTextField(
                            value = valorProfile,
                            onValueChange = {valorProfile = it},
                            placeholder = {
                                Text(
                                    text = "Escolha um tipo de perfil",
                                    fontSize = 18.sp
                                )                                
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = Color(255, 250, 247, 255),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .border(
                                    BorderStroke(
                                        width = 0.5.dp,
                                        color = Color(7, 72, 78, 255),
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ),
                            enabled = false
                        )
                    }
                }
                if(errorPerfil){
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                    ){
                        Text(
                            text = "Selecione um perfil",
                            fontSize = 14.sp,
                            color = Color.Red,
                            textAlign = TextAlign.End,
                            modifier = Modifier
                                .fillMaxWidth()
                        )
                    }
                }
            }
            Row (
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ){
                FloatingActionButton(
                    onClick = {
                        errorFirstName = firstname.isEmpty()
                        errorLastName = lastname.isEmpty()
                        errorUser = user.isEmpty()
                        errorEmail = email.isEmpty()
                        errorPassword = password.isEmpty()
                        errorPerfil = valorProfile.isEmpty()

                        if(
                            !firstname.isEmpty()  &&
                            !lastname.isEmpty() &&
                            !user.isEmpty() &&
                            !email.isEmpty() &&
                            !password.isEmpty() &&
                            !valorProfile.isEmpty()
                            ) {
                                val call = RetrofitFactory().setUser().setCadastroUser(
                                    Usuario(
                                        user = user,
                                        password = password,
                                        firstName = firstname,
                                        lastName = lastname,
                                        email = email,
                                        userProfile = arrayOf(
                                            Perfil(
                                                id = valorId,
                                                profileName = valorProfile
                                            )
                                        )

                                    )
                                )

                                call.enqueue(object : Callback<Usuario>{
                                    override fun onResponse(
                                        call: Call<Usuario>,
                                        response: Response<Usuario>
                                    ) {
                                        //Log.i("Cookcraft", "onResponse: ${response.body()}, ${response}")
                                        if(response.code() == 201) {
                                            userState = response.body()!!
                                            runBlocking {
                                                launch {
                                                    delay(1000L)
                                                }
                                            }
                                            exibirDialogCadastroEfetuado = true
                                            runBlocking {
                                                launch {
                                                    delay(5000L)
                                                }
                                                navController.navigate("login")
                                            }
                                        }else{
                                            firstname = ""
                                            lastname = ""
                                            user = ""
                                            email = ""
                                            password = ""
                                            valorProfile = ""
                                            runBlocking {
                                                launch {
                                                    delay(1000L)

                                                }
                                                exibirDialogCadastroNaoEfetuado = true
                                            }

                                            runBlocking {
                                                launch {
                                                    delay(5000L)
                                                }
                                                exibirDialogCadastroNaoEfetuado = false
                                            }
                                        }
                                    }

                                    override fun onFailure(call: Call<Usuario>, t: Throwable) {
                                        Log.i("Cookcraft", "onResponse: ${t.message}")
                                    }

                                })
                            }
                        },
                    modifier = Modifier
                        .width(200.dp)
                        .height(60.dp),
                    contentColor = Color(255, 250, 247, 255),
                    shape = RoundedCornerShape(10.dp),
                    containerColor = Color(7, 72, 78, 255)
                ) {
                    Text(text = "Cadastrar", fontSize = 20.sp)
                }
            }
        }
    }
}

