package br.com.fiap.cookcraft.service

import br.com.fiap.cookcraft.model.Auth
import br.com.fiap.cookcraft.model.LoginResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

interface AuthService {
    //BASE_URL - https://localhost:8080/api/v1/

    @Headers("Content-Type: application/json")
    @POST("auth")
    fun authByUser(
        @Body model: Auth
    ): Call<LoginResponse>
}