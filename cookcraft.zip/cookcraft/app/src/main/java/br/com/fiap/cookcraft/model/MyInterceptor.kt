package br.com.fiap.cookcraft.model

import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response

class MyInterceptor(private val tokenType: String, private val token: String): Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request: Request = chain.request()
            .newBuilder()
            .addHeader(
                "Authorization",
                "$tokenType $token"
            )
            .build()
        return chain.proceed(request)
    }

}