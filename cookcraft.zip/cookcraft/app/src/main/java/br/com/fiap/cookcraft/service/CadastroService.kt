package br.com.fiap.cookcraft.service

import br.com.fiap.cookcraft.model.Usuario
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

interface CadastroService {
    @Headers("Content-Type: application/json")
    @POST("users")
    fun setCadastroUser(
        @Body model: Usuario
    ): Call <Usuario>
}