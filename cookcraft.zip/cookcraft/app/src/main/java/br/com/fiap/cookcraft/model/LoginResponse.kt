package br.com.fiap.cookcraft.model

data class LoginResponse(
    val path: String = "",
    val method: String = "",
    val status: Int = 0,
    val statusMessage: String = "",
    val message: String = "",
    val token: String = "",
)