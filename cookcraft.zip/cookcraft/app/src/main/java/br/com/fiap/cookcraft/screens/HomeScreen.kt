package br.com.fiap.cookcraft.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import br.com.fiap.cookcraft.R
import br.com.fiap.cookcraft.components.MenuInferior

/*Página de Home*/
@Composable
fun HomeScreen(
    navController: NavController,
    token: String
){
    var buscaReceita by remember{
        mutableStateOf("")
    }

    Column(

        modifier = Modifier
            .fillMaxSize()
            .background(
                Color(253, 160, 106, 255)
            )
            .drawBehind {
                translate(left = 350f, top = -630f) {
                    drawCircle(
                        color = Color(238, 192, 158, 255),
                        radius = 160.dp.toPx()
                    )
                }
                translate(left = -350f, top = -470f) {
                    drawCircle(
                        color = Color(238, 192, 158, 255),
                        radius = 80.dp.toPx()
                    )
                }
                translate(left = -370f, top = 300f) {
                    drawCircle(
                        color = Color(238, 192, 158, 255),
                        radius = 180.dp.toPx()
                    )
                }
                translate(left = 430f, top = 100f) {
                    drawCircle(
                        color = Color(238, 192, 158, 255),
                        radius = 40.dp.toPx()
                    )
                }
                translate(left = 350f, top = 800f) {
                    drawCircle(
                        color = Color(238, 192, 158, 255),
                        radius = 100.dp.toPx()
                    )
                }
            },
        verticalArrangement = Arrangement.SpaceBetween
    ){
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp),
        ){
            Column (
                modifier = Modifier
                    .fillMaxHeight()
                    .width(200.dp)
                    .background(
                        Color(7, 72, 78, 255),
                        RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp)
                    ),
                verticalArrangement =  Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ){
                Image(
                    painter = painterResource(id = R.drawable.cookcraft_logo2),
                    contentDescription = "Logo Cookcraft",
                    modifier = Modifier
                        .size(width = 200.dp, height = 80.dp)
                        .clip(
                            shape = RoundedCornerShape(6.dp)
                        ),
                )
            }
        }
        Row(modifier = Modifier
            .fillMaxWidth()
            .height(50.dp),
            horizontalArrangement = Arrangement.End
        ){
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(300.dp),
                horizontalAlignment = Alignment.Start,
                verticalArrangement = Arrangement.Center
            ){
                OutlinedTextField(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                        .background(
                            color = Color(7, 72, 78, 255),
                            RoundedCornerShape(
                                topEnd = 0.dp,
                                bottomEnd = 0.dp,
                                topStart = 8.dp,
                                bottomStart = 8.dp
                            )
                        ),
                    value = buscaReceita,
                    onValueChange = {letra ->
                        buscaReceita = letra
                    },
                    placeholder = {
                        Text(
                            text = "Procure mais receitas",
                            textAlign = TextAlign.Center,
                            color = Color(255, 250, 247, 255)
                        )
                    },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(
                                id = R.drawable.baseline_search_24
                            ),
                            contentDescription = "",
                            tint = Color(255, 250, 247, 255)
                        )

                    },
                    shape = RoundedCornerShape(topEnd = 0.dp, bottomEnd = 0.dp, topStart = 8.dp, bottomStart = 8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(255, 142, 78, 255),
                        unfocusedBorderColor = Color(160,160,160,255),
                        focusedTextColor = Color(255, 250, 247, 255)
                    )
                )
            }
        }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 26.dp)
            /*.background(
                color = Color(233, 233, 233, 255),
            )*/,
            //verticalArrangement = Arrangement.SpaceEvenly,
        )
        {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ){
                Column(
                    modifier = Modifier
                        .padding(horizontal = 6.dp)
                ){
                    Text(
                        text = "Ingredientes e Tempo:",
                        style = TextStyle(
                            fontSize = 20.sp,
                            shadow = Shadow(
                                color = Color(89,74,71,255),
                                blurRadius = 3f
                            ),
                            color = Color(89,74,71,255)
                        )
                    )
                }
                Column(
                    modifier = Modifier
                        .padding(horizontal = 6.dp)
                ){
                    Text(
                        text = "Ver mais ...",
                        color = Color(89,74,71,255)
                    )
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(
                        color = Color(200, 200, 200, 255),
                        shape = RoundedCornerShape(20.dp)
                    ),
                horizontalArrangement = Arrangement.Center
            ){
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            color = Color(255, 250, 247, 255),
                            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
                        )
                ){
                    Text(
                        modifier = Modifier
                            .padding(vertical = 6.dp)
                            .fillMaxWidth(),
                        text = "Suco de Cenoura",
                        style = TextStyle(
                            fontSize = 18.sp,
                            shadow = Shadow(
                                color = Color.Black,
                                blurRadius = 2f
                            ),
                            color = Color(89,74,71,255)
                        ),
                        textAlign = TextAlign.Center
                    )
                }
                Column(){

                }
                Column(){

                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ){
                Column(
                    modifier = Modifier
                        .padding(horizontal = 6.dp)

                ){
                    Text(
                        text = "Desafios:",
                        style = TextStyle(
                            fontSize = 20.sp,
                            shadow = Shadow(
                                color = Color(89,74,71,255),
                                blurRadius = 3f
                            ),
                            color = Color(89,74,71,255)
                        )
                    )
                }
                Column(
                    modifier = Modifier
                        .padding(horizontal = 6.dp)
                ){
                    Text(
                        text = "Ver mais ...",
                        color = Color(89,74,71,255)
                    )
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(
                        color = Color(200, 200, 200, 255),
                        shape = RoundedCornerShape(20.dp)
                    )
            ){
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            color = Color(255, 250, 247, 255),
                            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
                        )
                ){
                    Text(
                        modifier = Modifier
                            .padding(vertical = 6.dp)
                            .fillMaxWidth(),
                        text = "Suflê de Cenoura",
                        style = TextStyle(
                            fontSize = 18.sp,
                            shadow = Shadow(
                                color = Color(89,74,71,255),
                                blurRadius = 2f
                            ),
                            color = Color(89,74,71,255)
                        ),
                        textAlign = TextAlign.Center
                    )
                }
                Column(){
                }
                Column(){
                }
            }
        }
        MenuInferior(token, navController)
    }
}

@Preview(showSystemUi = true, showBackground = true)
@Composable
fun HomePreview(){
    //HomeScreen()
}