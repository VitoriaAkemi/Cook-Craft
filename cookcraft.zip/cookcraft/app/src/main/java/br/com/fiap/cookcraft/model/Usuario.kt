package br.com.fiap.cookcraft.model

data class Usuario(
    val user: String = "",
    val password: String = "",
    val firstName: String  = "",
    val lastName: String  = "",
    val email: String  = "",
    val userProfile: Array<Perfil>
)

