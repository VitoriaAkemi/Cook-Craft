package br.com.fiap.cookcraft.components


import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.node.ModifierNodeElement
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import br.com.fiap.cookcraft.R
import br.com.fiap.cookcraft.model.Ingrediente
import br.com.fiap.cookcraft.model.Receita


@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun CaixaDeDialogoReceita(
    receita: Receita,
    primaryAction: () -> Unit,
    corDaTela: Color
) {
    var stateDialog by remember {
        mutableStateOf(false)
    }
    Dialog(
        onDismissRequest = {primaryAction()},
        properties = DialogProperties(
            dismissOnClickOutside = true,
            usePlatformDefaultWidth = false
        ),
    ) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = corDaTela,
            modifier = Modifier
                .width(300.dp)
                .height(500.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(
                        10.dp
                    ),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row (
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            color = Color(255, 250, 247, 255),
                            shape = RoundedCornerShape(10.dp)
                        )
                        .padding(top = 10.dp, bottom = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ){
                    Text(
                        text = "${receita.nomeReceita}",
                        fontSize = 24.sp,
                        color = Color(7, 72, 78, 255),
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
                Column {
                    Row (
                        modifier = Modifier
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ){
                        Text(
                            text = "${receita.tempoPreparo}",
                            fontSize = 20.sp,
                            color = Color(89, 74, 71, 255),
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ){
                        Column(
                            modifier = Modifier
                                .width(145.dp)
                        ) {
                            for(ingrediente in receita.ingredientes){
                                Row (
                                    modifier = Modifier
                                        .height(40.dp),
                                    horizontalArrangement = Arrangement.Center
                                ){
                                    Text(
                                        text = "${ingrediente.nomeIngrediente}",
                                        fontSize = 16.sp,
                                        color = Color(89, 74, 71, 255),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                        Column(
                            modifier = Modifier
                                .width(145.dp)
                        ) {
                            for(ingrediente in receita.ingredientes){
                                Row (
                                    modifier = Modifier
                                        .height(40.dp),
                                    horizontalArrangement = Arrangement.Center
                                ){
                                    Text(
                                        text = "${ingrediente.quantidade}",
                                        fontSize = 16.sp,
                                        color = Color(89, 74, 71, 255),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }


                }
                Spacer(modifier = Modifier.height(20.dp))
                Row (
                    modifier = Modifier
                        .fillMaxWidth()
                        ,
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ){
                    IconButton(
                        onClick = {primaryAction()},
                        modifier = Modifier
                            .size(46.dp)
                            .background(
                                color = Color(255, 250, 247, 255),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .border(
                                BorderStroke(
                                    width = 0.5.dp,
                                    color = Color(7, 72, 78, 255),
                                ),
                                shape = RoundedCornerShape(10.dp)
                            )
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Perfil",
                            tint = Color(7, 72, 78, 255),
                            modifier = Modifier
                                .size(30.dp)
                                .padding(0.dp)
                        )
                    }
                }
            }
        }
    }
}
