package br.com.fiap.cookcraft.service

import br.com.fiap.cookcraft.model.Perfil
import retrofit2.Call
import retrofit2.http.GET

interface PerfisService {
    @GET("profiles")
    fun getAllPerfis():Call <List<Perfil>>
}