package br.com.fiap.cookcraft.model

data class Perfil(
    val id: Int = 0,
    val profileName: String = ""
)