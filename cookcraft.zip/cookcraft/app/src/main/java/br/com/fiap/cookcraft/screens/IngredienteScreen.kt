package br.com.fiap.cookcraft.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

/*Página de Ingredientes*/

@Composable
fun IngredienteScreen(navController: NavController) {

    var ingrediente by remember{
        mutableStateOf("")
    }

    var quantidade by remember{
        mutableStateOf("")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                color = Color(255, 250, 247, 255)
            )
    ){
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .padding(start = 26.dp, bottom = 26.dp, end = 26.dp)
                .background(
                    color = Color(238, 192, 158, 255),
                    shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp)
                ),
            verticalArrangement = Arrangement.SpaceBetween
        ){
            Row(
                modifier = Modifier
                    .fillMaxWidth()
            ){
                Text(
                    text = "Liste os ingredientes que você possui em casa.",
                    style = TextStyle(
                        fontSize = 26.sp,
                        color = Color.Black,
                        textAlign = TextAlign.Center
                    ),
                    modifier = Modifier
                        .padding(vertical = 10.dp)
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ){
                OutlinedTextField(
                    modifier = Modifier
                        .padding(vertical = 10.dp, horizontal = 6.dp)
                        .width(180.dp)
                        .background(
                            color = Color(255, 250, 247, 255),
                            shape = RoundedCornerShape(6.dp)
                        ),
                    value = ingrediente,
                    onValueChange = {ingrediente = it},
                    singleLine = true,
                    placeholder = {
                        Text(
                            text = "Ingrediente",
                            style = TextStyle(
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        )
                    },
                    textStyle = TextStyle(
                        fontSize = 18.sp
                    )
                )
                OutlinedTextField(
                    modifier = Modifier
                        .padding(vertical = 10.dp, horizontal = 6.dp)
                        .width(100.dp)
                        .background(
                            color = Color(255, 250, 247, 255),
                            shape = RoundedCornerShape(6.dp)
                        ),
                    value = quantidade,
                    onValueChange = {quantidade = it},
                    placeholder = {
                        Text(
                            text = "Quantidade",
                            style = TextStyle(
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center,
                            )
                        )
                    },
                    textStyle = TextStyle(
                        fontSize = 18.sp
                    ),
                    keyboardOptions =  KeyboardOptions(
                        keyboardType = KeyboardType.Number
                    )
                )
            }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(400.dp)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(238, 192, 158, 255)),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceEvenly
                ){
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .background(
                                color = Color(255, 142, 78, 255),
                                shape = RoundedCornerShape(10.dp)
                            )
                    ){
                        Column(

                        ){

                        }
                        Column(

                        ){

                        }
                    }
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp)
                    .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ){
                Button(
                    onClick = { /*TODO*/ },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(125, 208, 216, 255)
                    ),
                    modifier = Modifier
                        .height(50.dp)
                        .width(150.dp),
                    contentPadding = PaddingValues(0.dp),
                    elevation = ButtonDefaults.buttonElevation(
                        defaultElevation = 14.dp,
                        pressedElevation = 5.dp,
                        disabledElevation = 0.dp
                    )
                ) {
                    Text(
                        text = "Adicionar",
                        style = TextStyle(
                            fontSize = 20.sp,
                            textAlign = TextAlign.Center,
                            color = Color.Black
                        ),
                        modifier = Modifier
                            .padding(vertical = 0.dp)
                    )
                }
                Button(
                    onClick = { /*TODO*/ },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(125, 208, 216, 255)
                    ),
                    modifier = Modifier
                        .height(50.dp)
                        .width(150.dp),
                    contentPadding = PaddingValues(0.dp),
                    elevation = ButtonDefaults.buttonElevation(
                        defaultElevation = 14.dp,
                        pressedElevation = 5.dp,
                        disabledElevation = 0.dp
                    )
                ) {
                    Text(
                        text = "Concluir",
                        style = TextStyle(
                            fontSize = 20.sp,
                            textAlign = TextAlign.Center,
                            color = Color.Black
                        ),
                        modifier = Modifier
                            .padding(vertical = 0.dp)
                    )
                }
            }
        }
    }
}