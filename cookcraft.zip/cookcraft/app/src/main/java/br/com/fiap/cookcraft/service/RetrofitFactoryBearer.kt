package br.com.fiap.cookcraft.service

import br.com.fiap.cookcraft.model.MyInterceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetrofitFactoryBearer(token:String) {
    private val BASE_URL = "http://10.0.2.2:8080/api/v1/"

    val client = OkHttpClient.Builder().apply {
        addInterceptor(MyInterceptor("Bearer", token))
    }.build()

    val retrofitFactory = Retrofit
        .Builder()
        .baseUrl(BASE_URL)
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    fun getAllReceitas(): ReceitaService{
        return retrofitFactory.create(ReceitaService::class.java)
    }
}