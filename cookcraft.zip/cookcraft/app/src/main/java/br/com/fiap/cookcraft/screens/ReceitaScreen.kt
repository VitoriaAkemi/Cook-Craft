package br.com.fiap.cookcraft.screens

import android.content.ClipData.Item
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import br.com.fiap.cookcraft.R
import br.com.fiap.cookcraft.components.ListaReceita
import br.com.fiap.cookcraft.components.MenuInferior
import br.com.fiap.cookcraft.model.Ingrediente
import br.com.fiap.cookcraft.model.Receita
import br.com.fiap.cookcraft.service.RetrofitFactoryBearer
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


/*Página de Receitas*/
@Composable
fun ReceitaScreen(
    navController: NavController,
    token: String
) {
    var stateListaReceita by remember {
        mutableStateOf(listOf<Receita>())
    }
    var stateLista by remember {
        mutableStateOf(false)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                color = Color(253, 160, 106, 255),
            ),
        verticalArrangement = Arrangement.SpaceBetween

    ){
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = Color(7, 72, 78, 255)
                )
                .height(70.dp)
        ) {
            Column(){
                Image(
                    painter = painterResource(id = R.drawable.cookcraft_logo2),
                    contentDescription = "Logo Cookcraft",
                    modifier = Modifier
                        .size(width = 200.dp, height = 80.dp)
                        .clip(
                            shape = RoundedCornerShape(6.dp)
                        ),
                )
            }
            Column(
                modifier = Modifier
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ){
                Text(
                    text = "Receitas",
                    fontSize = 22.sp,
                    color = Color(217,217,217, 255)
                )
            }
        }
        //Conteudo central
        Column(
            modifier = Modifier
                .width(400.dp)
                .background(
                    color = Color(238, 192, 158, 255)
                )
                .height(600.dp)
        ) {

                val call = RetrofitFactoryBearer(token).getAllReceitas().getAllReceita()
                call.enqueue(object: Callback<List<Receita>>{
                    override fun onResponse(
                        call: Call<List<Receita>>,
                        response: Response<List<Receita>>
                    ) {
                        //Log.i("Cookcraft", "onResponse: ${response}")
                        if(response.code() == 200){
                            stateListaReceita = response.body()!!
                            stateLista = true
                        }else{
                            stateListaReceita = listOf(
                                Receita(
                                    id = 0,
                                    nomeReceita = "",
                                    ingredientes = arrayOf(
                                        Ingrediente(
                                            id = 0,
                                            nomeIngrediente = "",
                                            quantidade = ""
                                        )
                                    )
                                )
                            )
                        }
                    }

                    override fun onFailure(call: Call<List<Receita>>, t: Throwable) {
                        Log.i("Cookcraft", "onResponse: ${t.message} ${t} ${token}")
                    }

                })
            if(stateLista){
                LazyColumn(
                    modifier = Modifier
                        .padding(10.dp)
                ){
                    items(stateListaReceita){
                        ListaReceita(it, navController, token)
                    }
                }
            }

        }
        MenuInferior(token, navController)
    }
}

